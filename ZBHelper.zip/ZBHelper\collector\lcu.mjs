// 롤 클라이언트 로컬 API(LCU) 접속 모듈. 127.0.0.1에서만 통신한다.
import { readFileSync, existsSync } from "node:fs";
import https from "node:https";
import os from "node:os";
import path from "node:path";

const LOCKFILE_CANDIDATES = [
  path.join(os.homedir(), "Riot Games", "League of Legends", "lockfile"),
  "C:\\Riot Games\\League of Legends\\lockfile",
  "D:\\Riot Games\\League of Legends\\lockfile",
];

/** 클라이언트가 켜져 있으면 {port, auth}, 아니면 null */
export function readLockfile() {
  const p = (process.env.LOL_LOCKFILE ? [process.env.LOL_LOCKFILE] : LOCKFILE_CANDIDATES).find((f) => existsSync(f));
  if (!p) return null;
  try {
    const [, , port, password] = readFileSync(p, "utf8").split(":");
    return { port, auth: "Basic " + Buffer.from(`riot:${password}`).toString("base64") };
  } catch {
    return null; // 클라이언트 종료 중 등
  }
}

export function lcu(conn, apiPath) {
  return new Promise((resolve, reject) => {
    https
      .get(
        {
          host: "127.0.0.1",
          port: conn.port,
          path: apiPath,
          headers: { Authorization: conn.auth, Accept: "application/json" },
          rejectUnauthorized: false, // 클라이언트가 자체 서명 인증서를 씀 (localhost 전용)
          timeout: 15000,
        },
        (res) => {
          let body = "";
          res.setEncoding("utf8");
          res.on("data", (c) => (body += c));
          res.on("end", () => {
            if (res.statusCode >= 400) return reject(new Error(`LCU ${res.statusCode} ${apiPath}`));
            try {
              resolve(body ? JSON.parse(body) : null);
            } catch (e) {
              reject(e);
            }
          });
        }
      )
      .on("timeout", function () {
        this.destroy(new Error(`LCU timeout ${apiPath}`));
      })
      .on("error", reject);
  });
}
