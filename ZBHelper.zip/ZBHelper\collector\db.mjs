// 로컬 SQLite DB (Node 내장 node:sqlite 사용, 별도 설치 불필요)
import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
export const DB_PATH = process.env.DB_PATH || path.join(ROOT, "data", "mayhem.db");

// 아수라장(증바람) 계열 큐
export const MAYHEM_QUEUES = new Set([2400, 3270]);

export function openDb() {
  mkdirSync(path.dirname(DB_PATH), { recursive: true });
  const db = new DatabaseSync(DB_PATH);
  db.exec(`
    PRAGMA journal_mode = WAL;

    CREATE TABLE IF NOT EXISTS augments (
      id INTEGER PRIMARY KEY,
      name TEXT, simple_name TEXT, rarity TEXT,
      description TEXT, icon_url TEXT
    );

    CREATE TABLE IF NOT EXISTS champions (
      id INTEGER PRIMARY KEY,
      name TEXT, alias TEXT, icon_url TEXT
    );

    CREATE TABLE IF NOT EXISTS items (
      id INTEGER PRIMARY KEY,
      name TEXT, price_total INTEGER,
      is_core INTEGER,         -- 완성 아이템 (전설급)
      is_boots INTEGER,        -- 완성 신발
      icon_url TEXT
    );

    CREATE TABLE IF NOT EXISTS matches (
      game_id INTEGER PRIMARY KEY,
      platform_id TEXT,
      queue_id INTEGER,
      game_mode TEXT,
      game_version TEXT,
      patch TEXT,              -- 예: 16.22
      created_at INTEGER,      -- ms
      duration_sec INTEGER,
      collected_at INTEGER,
      uploaded INTEGER DEFAULT 0,
      raw_json TEXT
    );

    CREATE TABLE IF NOT EXISTS participants (
      game_id INTEGER,
      participant_id INTEGER,
      puuid TEXT, game_name TEXT, tag_line TEXT,
      team_id INTEGER,
      champion_id INTEGER,
      win INTEGER,
      kills INTEGER, deaths INTEGER, assists INTEGER,
      damage_to_champions INTEGER,
      gold INTEGER,
      champ_level INTEGER,
      aug1 INTEGER, aug2 INTEGER, aug3 INTEGER, aug4 INTEGER, aug5 INTEGER, aug6 INTEGER,
      items TEXT,              -- JSON 배열 [item0..item6]
      PRIMARY KEY (game_id, participant_id)
    );

    -- 다른 플레이어 전적 수집 상태
    CREATE TABLE IF NOT EXISTS crawl (
      puuid TEXT PRIMARY KEY,
      last_crawled INTEGER,
      games_found INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);

    CREATE INDEX IF NOT EXISTS idx_part_champ ON participants(champion_id);
    CREATE INDEX IF NOT EXISTS idx_part_puuid ON participants(puuid);
    CREATE INDEX IF NOT EXISTS idx_match_patch ON matches(patch, queue_id);
  `);
  // 구버전 DB 마이그레이션: 증강 내부 ID 열 추가
  const cols = db.prepare("PRAGMA table_info(augments)").all().map((c) => c.name);
  if (!cols.includes("name_id")) db.exec("ALTER TABLE augments ADD COLUMN name_id TEXT");
  return db;
}

/**
 * 게임 공유용 압축 형식 (서버 업로드·다운로드에 사용, 원본 JSON보다 30배 이상 작음)
 * { gameId, platformId, queueId, gameMode, gameVersion, gameCreation, gameDuration,
 *   participants: [{ participantId, puuid, gameName, tagLine, teamId, championId, win,
 *                    kills, deaths, assists, damage, gold, level, augs[6], items[7] }] }
 */
export function toCompact(g) {
  const ids = new Map((g.participantIdentities || []).map((i) => [i.participantId, i.player || {}]));
  return {
    gameId: g.gameId, platformId: g.platformId ?? null, queueId: g.queueId, gameMode: g.gameMode,
    gameVersion: g.gameVersion, gameCreation: g.gameCreation ?? null, gameDuration: g.gameDuration ?? null,
    participants: (g.participants || []).map((p) => {
      const s = p.stats || {};
      const who = ids.get(p.participantId) || {};
      return {
        participantId: p.participantId, puuid: who.puuid ?? null, gameName: who.gameName ?? null,
        tagLine: who.tagLine ?? null, teamId: p.teamId, championId: p.championId, win: s.win ? 1 : 0,
        kills: s.kills ?? 0, deaths: s.deaths ?? 0, assists: s.assists ?? 0,
        damage: s.totalDamageDealtToChampions ?? 0, gold: s.goldEarned ?? 0, level: s.champLevel ?? 0,
        augs: [1, 2, 3, 4, 5, 6].map((i) => s[`playerAugment${i}`] ?? 0),
        items: [0, 1, 2, 3, 4, 5, 6].map((i) => s[`item${i}`] ?? 0),
      };
    }),
  };
}

/** DB에 있는 게임을 압축 형식으로 */
export function loadCompact(db, gameId) {
  const m = db.prepare("SELECT * FROM matches WHERE game_id = ?").get(gameId);
  if (!m) return null;
  const ps = db.prepare("SELECT * FROM participants WHERE game_id = ? ORDER BY participant_id").all(gameId);
  return {
    gameId: m.game_id, platformId: m.platform_id, queueId: m.queue_id, gameMode: m.game_mode,
    gameVersion: m.game_version, gameCreation: m.created_at, gameDuration: m.duration_sec,
    participants: ps.map((p) => ({
      participantId: p.participant_id, puuid: p.puuid, gameName: p.game_name, tagLine: p.tag_line,
      teamId: p.team_id, championId: p.champion_id, win: p.win, kills: p.kills, deaths: p.deaths,
      assists: p.assists, damage: p.damage_to_champions, gold: p.gold, level: p.champ_level,
      augs: [p.aug1, p.aug2, p.aug3, p.aug4, p.aug5, p.aug6], items: JSON.parse(p.items || "[]"),
    })),
  };
}

/** 압축 형식 게임을 DB에 저장. 새로 저장했으면 true. uploaded=1이면 서버에서 받은 게임(다시 올리지 않음) */
export function saveCompact(db, c, { raw = null, uploaded = 0 } = {}) {
  if (db.prepare("SELECT 1 FROM matches WHERE game_id = ?").get(c.gameId)) return false;
  const patch = (c.gameVersion || "").split(".").slice(0, 2).join(".");
  db.exec("BEGIN");
  try {
    db.prepare(
      `INSERT INTO matches (game_id, platform_id, queue_id, game_mode, game_version, patch, created_at, duration_sec, collected_at, uploaded, raw_json)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      c.gameId, c.platformId ?? null, c.queueId, c.gameMode ?? null, c.gameVersion ?? null, patch,
      c.gameCreation ?? null, c.gameDuration ?? null, Date.now(), uploaded, raw
    );
    const ins = db.prepare(`INSERT INTO participants VALUES (${Array(21).fill("?").join(",")})`);
    for (const p of c.participants || []) {
      const a = p.augs || [];
      ins.run(
        c.gameId, p.participantId, p.puuid ?? null, p.gameName ?? null, p.tagLine ?? null,
        p.teamId, p.championId, p.win ? 1 : 0, p.kills ?? 0, p.deaths ?? 0, p.assists ?? 0,
        p.damage ?? 0, p.gold ?? 0, p.level ?? 0,
        a[0] ?? 0, a[1] ?? 0, a[2] ?? 0, a[3] ?? 0, a[4] ?? 0, a[5] ?? 0,
        JSON.stringify(p.items || [])
      );
    }
    db.exec("COMMIT");
    return true;
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}

/** LCU 게임 상세 JSON을 DB에 저장. 새로 저장했으면 true */
export function saveGame(db, g) {
  return saveCompact(db, toCompact(g), { raw: JSON.stringify(g) });
}
