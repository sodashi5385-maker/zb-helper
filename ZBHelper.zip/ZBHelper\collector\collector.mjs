// 증바람 게임 자동 수집기
// - 롤 클라이언트가 켜져 있으면 전적에서 아수라장 게임을 찾아 DB에 저장
// - 켜둔 채로 두면 1분마다 새 게임을 확인 (게임이 끝나면 자동으로 쌓임)
// 사용법: node collector/collector.mjs          (계속 실행)
//         node collector/collector.mjs --once   (한 번만 수집하고 종료)
import { readLockfile, lcu } from "./lcu.mjs";
import { openDb, saveGame, MAYHEM_QUEUES, DB_PATH } from "./db.mjs";
import { syncStatic } from "./sync-static.mjs";
import { crawlLoop } from "./crawler.mjs";
import { shareLoop } from "./share.mjs";

const ONCE = process.argv.includes("--once");
const CRAWL = process.argv.includes("--crawl"); // 다른 플레이어 전적도 수집
const si = process.argv.indexOf("--server");      // 통계 서버와 공유 (예: --server http://localhost:8787)
const SERVER = si > 0 ? process.argv[si + 1] : process.env.ZB_SERVER;
const POLL_MS = 60_000;
const PAGE = 20;      // LCU 전적 페이지 크기
const MAX_BACKFILL = 200; // 처음 실행 시 과거 전적을 몇 판까지 훑을지

const db = openDb();
const log = (...a) => console.log(new Date().toLocaleTimeString("ko-KR"), ...a);

async function collect(conn, depth) {
  let saved = 0;
  let seenKnown = false;
  for (let beg = 0; beg < depth && !seenKnown; beg += PAGE) {
    const hist = await lcu(conn, `/lol-match-history/v1/products/lol/current-summoner/matches?begIndex=${beg}&endIndex=${beg + PAGE - 1}`);
    const games = hist?.games?.games ?? [];
    if (!games.length) break;
    for (const g of games) {
      if (!MAYHEM_QUEUES.has(g.queueId)) continue;
      if (db.prepare("SELECT 1 FROM matches WHERE game_id = ?").get(g.gameId)) {
        if (depth === PAGE) seenKnown = true; // 평소 확인 때는 이미 저장된 게임을 만나면 중단
        continue;
      }
      const detail = await lcu(conn, `/lol-match-history/v1/games/${g.gameId}`);
      if (saveGame(db, detail)) {
        saved++;
        log(`  + 저장: ${g.gameId} (큐 ${g.queueId}, ${new Date(detail.gameCreation).toLocaleString("ko-KR")})`);
      }
    }
  }
  return saved;
}

async function tick(first) {
  const conn = readLockfile();
  if (!conn) {
    if (first) log("롤 클라이언트가 꺼져 있습니다. 켜지면 자동으로 수집을 시작합니다.");
    return false;
  }
  try {
    const me = await lcu(conn, "/lol-summoner/v1/current-summoner");
    const saved = await collect(conn, first ? MAX_BACKFILL : PAGE);
    const total = db.prepare("SELECT COUNT(*) n FROM matches").get().n;
    if (first || saved) log(`${me.gameName}#${me.tagLine} | 새 게임 ${saved}판 저장 | DB 누적 ${total}판`);
    return true;
  } catch (e) {
    log("수집 실패 (클라이언트 로딩 중일 수 있음):", e.message);
    return false;
  }
}

log(`DB: ${DB_PATH}`);
if (!db.prepare("SELECT COUNT(*) n FROM augments").get().n) {
  log("증강·챔피언 데이터를 처음 받아옵니다...");
  const r = await syncStatic(db);
  log(`증강 ${r.augments}개, 챔피언 ${r.champions}개 저장`);
}

let ready = await tick(true);
if (!ONCE) {
  log("1분마다 새 증바람 게임을 확인합니다. 종료: Ctrl+C");
  setInterval(async () => {
    ready = (await tick(!ready)) || ready;
  }, POLL_MS);
  if (CRAWL) {
    log("다른 플레이어 증바람 전적 수집을 시작합니다 (천천히, 게임 중엔 멈춤)");
    crawlLoop(db, (s) => log(s)).catch((e) => log("[크롤] 오류로 중단: " + e.message));
  }
  if (SERVER) {
    log(`통계 서버와 공유합니다: ${SERVER}`);
    shareLoop(db, SERVER, (s) => log(s)).catch((e) => log("[공유] 오류로 중단: " + e.message));
  }
}
