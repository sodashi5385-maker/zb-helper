// 통계 서버와 데이터 공유
// - 올리기: 이 PC에서 수집한 증바람 게임(내 게임 + 다른 플레이어 게임)을 서버로 보낸다
// - 받기: 다른 사용자들이 올린 게임을 받아 로컬 DB에 넣는다 → 어드바이저 추천이 모두의 데이터 기준이 됨
import zlib from "node:zlib";
import { loadCompact, saveCompact } from "./db.mjs";

const INTERVAL_MS = 2 * 60_000;
const UPLOAD_BATCH = 100;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function shareLoop(db, server, log) {
  server = server.replace(/\/+$/, "");
  const getMeta = (k) => db.prepare("SELECT value FROM meta WHERE key = ?").get(k)?.value;
  const setMeta = (k, v) => db.prepare("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)").run(k, String(v));
  const cursorKey = "pull_cursor:" + server;
  let failures = 0;

  for (;;) {
    let up = 0, down = 0;
    try {
      // 올리기
      for (;;) {
        const ids = db.prepare("SELECT game_id FROM matches WHERE uploaded = 0 ORDER BY created_at LIMIT ?").all(UPLOAD_BATCH);
        if (!ids.length) break;
        const games = ids.map((r) => loadCompact(db, r.game_id)).filter(Boolean);
        const res = await fetch(server + "/api/upload", {
          method: "POST",
          headers: { "Content-Type": "application/json", "Content-Encoding": "gzip" },
          body: zlib.gzipSync(JSON.stringify({ client: "zb-app/1", games })),
        });
        if (!res.ok) throw new Error(`업로드 ${res.status}`);
        const r = await res.json();
        const mark = db.prepare("UPDATE matches SET uploaded = 1 WHERE game_id = ?");
        for (const { game_id } of ids) mark.run(game_id);
        up += r.accepted;
      }
      // 받기
      let cursor = Number(getMeta(cursorKey) || 0);
      for (;;) {
        const res = await fetch(`${server}/api/export?after=${cursor}&limit=300`);
        if (!res.ok) throw new Error(`받기 ${res.status}`);
        const r = await res.json();
        for (const g of r.games) if (saveCompact(db, g, { uploaded: 1 })) down++;
        if (r.next === cursor || !r.games.length) break;
        cursor = r.next;
        setMeta(cursorKey, cursor);
      }
      failures = 0;
      const total = db.prepare("SELECT COUNT(*) n FROM matches").get().n;
      log(`[공유] 서버 연결됨 · 올림 +${up} · 받음 +${down} | DB 누적 ${total}판`);
    } catch (e) {
      failures++;
      log(`[공유] 서버에 연결하지 못했습니다 (${e.cause?.code || e.message}) · 나중에 다시 시도`);
    }
    await sleep(failures ? Math.min(INTERVAL_MS * failures, 15 * 60_000) : INTERVAL_MS);
  }
}
