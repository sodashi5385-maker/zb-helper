// CommunityDragon에서 증강·챔피언 이름/아이콘을 받아 DB에 저장
// 사용법: node collector/sync-static.mjs   (패치 후 한 번씩 실행)
import { pathToFileURL } from "node:url";
import { existsSync, mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import { openDb, DB_PATH } from "./db.mjs";

const CD = "https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global";
const assetUrl = (p) =>
  p ? `${CD}/default/${p.replace(/^\/lol-game-data\/assets\//i, "").toLowerCase()}` : null;

async function getJson(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${res.status} ${url}`);
  return res.json();
}

export async function syncStatic(db = openDb(), { icons = true } = {}) {
  const [augs, champs] = await Promise.all([
    getJson(`${CD}/ko_kr/v1/cherry-augments.json`),
    getJson(`${CD}/ko_kr/v1/champion-summary.json`),
  ]);

  const insA = db.prepare(
    `INSERT OR REPLACE INTO augments (id, name, simple_name, rarity, description, icon_url, name_id) VALUES (?,?,?,?,?,?,?)`
  );
  db.exec("BEGIN");
  for (const a of augs) {
    // 이벤트용 증강 등은 이름이 공백 → 내부 ID로 대체
    const name = a.nameTRA?.trim() || `(${a.augmentNameId})`;
    insA.run(
      a.id, name, a.simpleNameTRA ?? null,
      (a.rarity || "").replace(/^k/, "").toLowerCase(), // gold / silver / prismatic
      a.summaryDescription ?? null, assetUrl(a.augmentSmallIconPath), a.augmentNameId ?? null
    );
  }
  const insC = db.prepare(`INSERT OR REPLACE INTO champions (id, name, alias, icon_url) VALUES (?,?,?,?)`);
  for (const c of champs) if (c.id > 0) insC.run(c.id, c.name, c.alias, assetUrl(c.squarePortraitPath));

  // 아이템: 완성 아이템/완성 신발만 구분해 둔다 (템트리 추천용)
  const items = await getJson(`${CD}/ko_kr/v1/items.json`);
  const insI = db.prepare(`INSERT OR REPLACE INTO items (id, name, price_total, is_core, is_boots, icon_url) VALUES (?,?,?,?,?,?)`);
  const iconTargets = [];
  for (const it of items) {
    const boots = (it.categories || []).includes("Boots") && it.priceTotal >= 900;
    const core = !boots && (it.to || []).length === 0 && it.priceTotal >= 2000;
    insI.run(it.id, it.name, it.priceTotal, core ? 1 : 0, boots ? 1 : 0, assetUrl(it.iconPath));
    if (core || boots) iconTargets.push([it.id, assetUrl(it.iconPath)]);
  }
  db.exec("COMMIT");

  // 오버레이에서 쓸 아이템 아이콘을 미리 받아둔다 (data/cache/items/<id>.png)
  const dir = path.join(path.dirname(DB_PATH), "cache", "items");
  mkdirSync(dir, { recursive: true });
  let downloaded = 0;
  for (let i = 0; icons && i < iconTargets.length; i += 16) {
    await Promise.all(
      iconTargets.slice(i, i + 16).map(async ([id, url]) => {
        const file = path.join(dir, `${id}.png`);
        if (existsSync(file) || !url) return;
        try {
          const res = await fetch(url);
          if (res.ok) {
            writeFileSync(file, Buffer.from(await res.arrayBuffer()));
            downloaded++;
          }
        } catch {}
      })
    );
  }

  return {
    augments: augs.length,
    champions: champs.filter((c) => c.id > 0).length,
    items: iconTargets.length,
    icons: downloaded,
  };
}

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  const r = await syncStatic();
  console.log(`✅ 증강 ${r.augments}개, 챔피언 ${r.champions}개, 완성 아이템 ${r.items}개 저장 (아이콘 새로 받음 ${r.icons}개)`);
}
