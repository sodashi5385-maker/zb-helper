// 수집된 데이터로 간단한 통계 출력 (나중에 사이트가 쓸 집계 쿼리의 원형)
// 사용법: node collector/stats.mjs            (전체 요약)
//         node collector/stats.mjs 럭스       (챔피언별 증강 승률)
import { openDb } from "./db.mjs";

const db = openDb();
const champArg = process.argv[2];
const pct = (w, n) => (n ? ((100 * w) / n).toFixed(1) + "%" : "-");

const total = db.prepare("SELECT COUNT(*) n FROM matches").get().n;
console.log(`수집된 증바람 게임: ${total}판 (참가자 ${total * 10}명분)\n`);

// 증강을 한 줄씩 펼친 뷰
const AUG_ROWS = `
  SELECT p.game_id, p.champion_id, p.win, a.value AS aug
  FROM participants p, json_each(json_array(p.aug1,p.aug2,p.aug3,p.aug4,p.aug5,p.aug6)) a
  WHERE a.value > 0
    -- 펜타킬 이벤트 버프(GoH_PentakillAug_*)는 고르는 증강이 아니라서 제외
    AND a.value NOT IN (SELECT id FROM augments WHERE name_id LIKE 'GoH\\_%' ESCAPE '\\')`;

if (champArg) {
  const c = db.prepare("SELECT id, name FROM champions WHERE name = ? OR alias = ? COLLATE NOCASE").get(champArg, champArg);
  if (!c) {
    console.log("챔피언을 찾지 못했습니다:", champArg);
    process.exit(1);
  }
  const base = db.prepare("SELECT COUNT(*) n, SUM(win) w FROM participants WHERE champion_id = ?").get(c.id);
  console.log(`${c.name}: ${base.n}판, 승률 ${pct(base.w, base.n)}\n`);
  const rows = db
    .prepare(
      `SELECT au.name, au.rarity, COUNT(*) n, SUM(r.win) w
       FROM (${AUG_ROWS}) r LEFT JOIN augments au ON au.id = r.aug
       WHERE r.champion_id = ? GROUP BY r.aug ORDER BY n DESC LIMIT 20`
    )
    .all(c.id);
  console.log("많이 고른 증강 (판수 / 승률)");
  for (const r of rows) console.log(`  ${(r.name ?? "?").padEnd(16)} [${r.rarity}] ${String(r.n).padStart(4)}판  ${pct(r.w, r.n)}`);
  process.exit(0);
}

console.log("챔피언 픽 순위 (판수 / 승률)");
for (const r of db
  .prepare(
    `SELECT c.name, COUNT(*) n, SUM(p.win) w FROM participants p
     LEFT JOIN champions c ON c.id = p.champion_id
     GROUP BY p.champion_id ORDER BY n DESC, w DESC LIMIT 15`
  )
  .all())
  console.log(`  ${(r.name ?? "?").padEnd(10)} ${String(r.n).padStart(4)}판  ${pct(r.w, r.n)}`);

console.log("\n증강 픽 순위 (판수 / 승률)");
for (const r of db
  .prepare(
    `SELECT au.name, au.rarity, COUNT(*) n, SUM(r.win) w
     FROM (${AUG_ROWS}) r LEFT JOIN augments au ON au.id = r.aug
     GROUP BY r.aug ORDER BY n DESC LIMIT 15`
  )
  .all())
  console.log(`  ${(r.name ?? "?").padEnd(16)} [${r.rarity}] ${String(r.n).padStart(4)}판  ${pct(r.w, r.n)}`);

console.log("\n※ 표본이 적을 때는 승률이 크게 흔들립니다. 사이트에서는 신뢰구간으로 보정할 예정입니다.");
