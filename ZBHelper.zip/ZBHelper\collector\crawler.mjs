// 다른 플레이어 증바람 전적 수집기 (롤 클라이언트 LCU 경유)
// - 이미 수집한 게임에 나온 플레이어들의 최근 전적(20판)을 받아 새 증바람 게임을 저장
// - 새 게임에 나온 플레이어가 다시 후보가 되므로 데이터가 계속 늘어난다
// - 계정 보호: 요청 간격 1.5초, 하루 최대 요청 수 제한, 게임 중(챔프 선택~게임 종료) 정지, 거절 시 점점 길게 쉼
import { readLockfile, lcu } from "./lcu.mjs";
import { saveGame, MAYHEM_QUEUES } from "./db.mjs";

const REQUEST_GAP_MS = 1500;
const DETAIL_GAP_MS = 300;
const DAILY_LIMIT = 3000;
const RECRAWL_AFTER_MS = 3 * 24 * 3600 * 1000;
const BUSY_PHASES = new Set(["ReadyCheck", "ChampSelect", "GameStart", "InProgress", "Reconnect", "WaitingForStats"]);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function crawlLoop(db, log) {
  const today = () => new Date().toISOString().slice(0, 10);
  const getMeta = (k) => db.prepare("SELECT value FROM meta WHERE key = ?").get(k)?.value;
  const setMeta = (k, v) => db.prepare("INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)").run(k, String(v));
  let used = getMeta("crawl_day") === today() ? Number(getMeta("crawl_used") || 0) : 0;
  let backoff = 0;
  let players = 0;
  let newGames = 0;
  let lastStatus = "";
  const status = (s) => {
    const total = db.prepare("SELECT COUNT(*) n FROM matches").get().n;
    const line = `[크롤] ${s} | DB 누적 ${total}판`;
    if (line !== lastStatus) {
      lastStatus = line;
      log(line);
    }
  };

  const request = async (conn, path) => {
    if (getMeta("crawl_day") !== today()) used = 0;
    used++;
    setMeta("crawl_day", today());
    setMeta("crawl_used", used);
    return lcu(conn, path);
  };

  status("시작 대기 중");
  for (;;) {
    const conn = readLockfile();
    if (!conn) {
      status("롤 클라이언트 꺼짐 · 대기");
      await sleep(15000);
      continue;
    }
    if (backoff) {
      status(`서버가 요청을 거절해 ${Math.round(backoff / 60000)}분 쉬는 중`);
      await sleep(backoff);
    }
    let phase = null;
    try {
      phase = await lcu(conn, "/lol-gameflow/v1/gameflow-phase");
    } catch {
      await sleep(10000);
      continue;
    }
    if (BUSY_PHASES.has(phase)) {
      status("게임 중이라 잠시 멈춤");
      await sleep(15000);
      continue;
    }
    if (getMeta("crawl_day") === today() && used >= DAILY_LIMIT) {
      status(`오늘 수집 한도 도달 (+${newGames}판) · 내일 다시 시작`);
      await sleep(10 * 60000);
      continue;
    }

    let me = null;
    try {
      me = (await lcu(conn, "/lol-summoner/v1/current-summoner")).puuid;
    } catch {}
    const target = db
      .prepare(
        `SELECT p.puuid FROM participants p
         JOIN matches m USING (game_id)
         LEFT JOIN crawl c ON c.puuid = p.puuid
         WHERE p.puuid IS NOT NULL AND p.puuid != '' AND p.puuid != ?
           AND (c.last_crawled IS NULL OR c.last_crawled < ?)
         ORDER BY m.created_at DESC LIMIT 1`
      )
      .get(me ?? "", Date.now() - RECRAWL_AFTER_MS);
    if (!target) {
      status(`조회할 새 플레이어 없음 (+${newGames}판) · 대기`);
      await sleep(5 * 60000);
      continue;
    }

    let found = 0;
    try {
      const hist = await request(conn, `/lol-match-history/v1/products/lol/${target.puuid}/matches?begIndex=0&endIndex=19`);
      const games = (hist?.games?.games ?? []).filter((g) => MAYHEM_QUEUES.has(g.queueId));
      for (const g of games) {
        if (db.prepare("SELECT 1 FROM matches WHERE game_id = ?").get(g.gameId)) continue;
        await sleep(DETAIL_GAP_MS);
        const detail = await request(conn, `/lol-match-history/v1/games/${g.gameId}`);
        if (detail && saveGame(db, detail)) found++;
      }
      backoff = 0;
    } catch (e) {
      const code = Number(/LCU (\d+)/.exec(e.message)?.[1]);
      if (code === 429 || code >= 500) {
        backoff = Math.min(backoff ? backoff * 2 : 60000, 30 * 60000);
        continue; // 이 플레이어는 나중에 다시
      }
      // 404 등: 다른 지역 계정 등 조회 불가 → 건너뜀
    }
    db.prepare("INSERT OR REPLACE INTO crawl (puuid, last_crawled, games_found) VALUES (?, ?, ?)").run(
      target.puuid, Date.now(), found
    );
    players++;
    newGames += found;
    status(`플레이어 ${players}명 조회 · +${newGames}판 · 오늘 요청 ${used}/${DAILY_LIMIT}`);
    await sleep(REQUEST_GAP_MS);
  }
}
